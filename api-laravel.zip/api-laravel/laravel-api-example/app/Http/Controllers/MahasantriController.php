<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Mahasantri;
use Illuminate\Support\Facades\Validator;

class MahasantriController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         // DIGUNAKAN UNTUK MENAMPILKAN DATA MAHASANTRI
         $mhs = Mahasantri::all();
         if (isset($mhs)) {
             $hasil = [
                 "message" => "Data Mahasantri",
                 "data" => $mhs
             ];
             return response()->json($hasil, 200);
         } else {
             $fails = [
                 "message" => "Data Mahasantri Tidak Ditemukan",
                 "data" => $mhs
             ];
             return response()->json($fails, 404);
         }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'nama_mhs' => 'required',
            'alamat_mhs' => 'required',
            'umur_mhs' => 'required |integer',
            'id_jrs' => 'required|integer',
        ];

        $validator = Validator::make($request->all(), $data);

        if ($validator->fails()) {
            $fails = [
                "message" => "Gagal MenambahkanData Mahasantri",
                "data" => $validator->errors()
            ];
            return response()->json($fails, 404);
        } else {
            $mhs = new Mahasantri();
            $mhs->nama_mhs = $request->nama_mhs;
            $mhs->alamat_mhs = $request->alamat_mhs;
            $mhs->umur_mhs = $request->umur_mhs;
            $mhs->id_jrs = $request->id_jrs;
            $mhs->save();
            $success = [
                "message" => "Data Mahasantri Berhasil Ditambahkan",
                "data" => $mhs
            ];
            return response()->json($success, 200);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $data = [
            'nama_mhs' => 'required',
            'alamat_mhs' => 'required',
            'umur_mhs' =>  'required|integer',
            'id_jrs' => 'required|integer',
        ];

        $validator = Validator::make($request->all(), $data);

        if ($validator->fails()) {
            $fails = [
                'message' => 'Data Tidak Valid',
                'data' => $validator->errors()
            ];
            return response()->json($fails, 400);
        } else {
            $mhs = new Mahasantri;
            $mhs->nama_mhs = $request->nama_mhs;
            $mhs->umur_mhs = $request->umur_mhs;
            $mhs->alamat_mhs = $request->alamat_mhs;
            $mhs->id_jrs = $request->id_jrs;
            $mhs->save();
            $success = [
                'message' => 'Data Mahasantri Berhasil ditambahkan',
                'data' => $mhs
            ];
            return response()->json($success, 200);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         // DIGUNAKAN UNTUK MENGHAPUS MAHASANTRI
         $mhs = Mahasantri::where('id', $id)->first();
         if (isset($mhs)) {
             $mhs->delete();
             $success = [
                 "message" => "Data Mahasantri Berhasil Dihapus",
                 "data" => $mhs
             ];
             return response()->json($success, 200);
         } else {
             $fails = [
                 "message" => "Data Mahasantri Tidak Ditemukan",
             ];
             return response()->json($fails, 404);
         }
    }
}
